import java.util.Scanner;

public class Ejecutadora {
    static void main() {
        Scanner sc = new Scanner(System.in);
        String ruta = "C:\\Users\\1DAW\\Desktop\\ArchivoCSV\\datos.csv";
        System.out.println("Introduce tu nombre, edad y ciudad");
        String datos = sc.nextLine();
        Escritura.escritura(ruta,datos);
    }
}
