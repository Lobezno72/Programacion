public class Ejecutadora {
    static void main() {
        String ruta= "C:\\Users\\1DAW\\Desktop\\ArchivoCSV\\datos.csv";
        Leer.Leer(ruta);
    }
}
