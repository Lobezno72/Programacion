import java.util.Scanner;

public class Ejecutar {
    static void main() {
        String ruta = "C:\\Users\\1DAW\\Desktop\\ArchivoCSV\\datos 2.csv";
        Leer.contarlineas(ruta);
    }
}
