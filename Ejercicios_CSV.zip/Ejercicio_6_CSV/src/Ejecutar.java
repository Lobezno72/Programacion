public class Ejecutar {
    public static void main(String[] args) {

        String ruta = "C:\\Users\\1DAW\\Desktop\\ArchivoCSV\\datos 2.csv";

        Leer.leerCSV(ruta);
    }
}