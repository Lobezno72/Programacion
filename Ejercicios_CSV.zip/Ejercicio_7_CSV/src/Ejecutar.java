public class Ejecutar {
    public static void main(String[] args) {

        String origen = "C:\\Users\\1DAW\\Desktop\\ArchivoCSV\\datos 2.csv";
        String destino = "C:\\Users\\1DAW\\Desktop\\ArchivoCSV\\copia-datos.csv";

        Leer.copiar(origen, destino);
    }
}