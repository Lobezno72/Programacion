
public class Ejecutadora {
    public static void main(String[] args) {
        LeerTXT leerejecutadora  = new LeerTXT();
        leerejecutadora.leer("C:\\Users\\1DAW\\Desktop\\ArchivoTXT\\archivo1.txt");
    }
}