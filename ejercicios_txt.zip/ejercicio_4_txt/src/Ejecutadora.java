import java.util.Scanner;

public class Ejecutadora {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduzca algo");
        String texto = sc.nextLine();
        String ruta = "C:\\Users\\1DAW\\Desktop\\ArchivoTXT\\archivo1.txt";
        EscribirTXT.escribir(ruta, texto, true);
        System.out.println("El texto || " + texto + " || ha sido añadido exitosamente");
        sc.close();
    }
}