import java.util.Scanner;

public class Ejecutadora {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduzca lo que quiera para sobreescribirlo en el documento");
        String frase = sc.nextLine();
        String ruta = "C:\\Users\\1DAW\\Desktop\\ArchivoTXT\\archivo1.txt";
        EscribirTXT.escribir(ruta, frase, false);
        System.out.println("El documento ha sido sobreescrito exitosamente");
        sc.close();
    }
}