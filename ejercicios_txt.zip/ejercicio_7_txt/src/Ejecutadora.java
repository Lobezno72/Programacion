import java.sql.SQLOutput;

public class Ejecutadora {
    public static void main(String[] args) {
        LeerTXT leerDocumento = new LeerTXT();
        String ruta1 = "C:\\Users\\1DAW\\Desktop\\ArchivoTXT\\archivo1.txt";
        String ruta2 = "C:\\Users\\1DAW\\Desktop\\ArchivoTXT\\archivo2.txt";
        String ruta3 = "C:\\Users\\1DAW\\Desktop\\ArchivoTXT\\archivo3.txt";
        System.out.println("Leyendo documento 1...");
        String contenido1 = leerDocumento.leer(ruta1);

        System.out.println("Leyendo documento 2...");
        String contenido2 = leerDocumento.leer(ruta2);

        String contenido3 = contenido1 + contenido2;
        System.out.println("Mezclando contenido");

        System.out.println("Leyendo documento 3 mezclado...");
        contenido3 = leerDocumento.leer(ruta3);

        EscribirTXT.escribir(ruta3, contenido3, false);


    }
}